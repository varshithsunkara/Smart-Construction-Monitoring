from flask import Flask, render_template, jsonify
import random

app = Flask(__name__)

@app.route('/data')
def data():
    data = {
        'temperature': round(random.uniform(25, 38), 2),
        'gas_level': round(random.uniform(100, 500), 2),
        'motion': random.choice([True, False])
    }
    return jsonify(data)

@app.route('/')
def index():
    return '<h2>Smart Construction Site Dashboard</h2><p>Live monitoring of safety and environment data.</p>'

if __name__ == '__main__':
    app.run(debug=True)
