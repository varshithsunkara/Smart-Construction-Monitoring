# IoT Sensor Simulation
import random, time

def read_sensors():
    data = {
        'temperature': round(random.uniform(25, 38), 2),
        'gas_level': round(random.uniform(100, 500), 2),
        'motion': random.choice([True, False])
    }
    return data

while True:
    print(read_sensors())
    time.sleep(2)
